package com.horizon.PostgreSQLCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostgreSqlCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.RestTemplateAPI1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTemplateApi1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

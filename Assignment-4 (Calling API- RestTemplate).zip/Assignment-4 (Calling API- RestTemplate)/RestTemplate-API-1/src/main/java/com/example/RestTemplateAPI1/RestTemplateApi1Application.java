package com.example.RestTemplateAPI1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestTemplateApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(RestTemplateApi1Application.class, args);
	}

}

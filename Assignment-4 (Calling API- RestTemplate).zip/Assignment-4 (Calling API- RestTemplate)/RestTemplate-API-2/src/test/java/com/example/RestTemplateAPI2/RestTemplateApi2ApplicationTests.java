package com.example.RestTemplateAPI2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTemplateApi2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
